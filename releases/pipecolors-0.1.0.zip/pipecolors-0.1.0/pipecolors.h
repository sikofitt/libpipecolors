#ifndef __PIPECOLORS_H
#define __PIPECOLORS_H
#endif
#include <termcap.h>
#ifdef __cplusplus
extern "C" {
#endif

void cprintf(const char* format, ...);

#ifdef __cplusplus
}
#endif

